¡Bienvenido al chat!

1. Para ejecutar los archivos:
   gcc server.c -o server && ./server
   gcc client.c -o client && ./client

2. Comandos del chat:
    - Para duplicarse -> .share
    - Para abandonar chat -> .exit
